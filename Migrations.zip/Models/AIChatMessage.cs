namespace financepro.Api.Models;

public class AIChatMessage
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string Role { get; set; } = string.Empty;

    public string Content { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}