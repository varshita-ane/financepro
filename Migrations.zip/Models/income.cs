namespace financepro.Api.Models;

public class Income
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string Source { get; set; } = string.Empty;

    public decimal Amount { get; set; }

    public string Category { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public DateTime Date { get; set; }
}