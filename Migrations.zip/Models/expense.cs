namespace financepro.Api.Models;

public class Expense
{
    public int Id { get; set; }

    public int UserId { get; set; }

    public string Description { get; set; } = string.Empty;

    public decimal Amount { get; set; }

    public string Category { get; set; } = string.Empty;

    public string Type { get; set; } = "Need";

    public DateTime Date { get; set; }
}