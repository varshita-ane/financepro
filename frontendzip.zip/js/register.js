const API_URL = "http://localhost:5102/api";

const form = document.getElementById("registerForm");
const message = document.getElementById("message");

form.addEventListener("submit", async function (event) {

    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword =
        document.getElementById("confirmPassword").value;


    /* =========================
       VALIDATION
    ========================= */

    if (!name || !email || !password || !confirmPassword) {

        showMessage(
            "Please fill in all fields.",
            "error"
        );

        return;
    }


    if (password.length < 6) {

        showMessage(
            "Password must be at least 6 characters.",
            "error"
        );

        return;
    }


    if (password !== confirmPassword) {

        showMessage(
            "Passwords do not match.",
            "error"
        );

        return;
    }


    /* =========================
       REQUEST DATA
    ========================= */

    const data = {

        name: name,

        email: email,

        password: password

    };


    console.log(
        "Register request:",
        {
            name: name,
            email: email
        }
    );


    try {

        const response = await fetch(
            `${API_URL}/Auth/register`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify(data)
            }
        );


        const result =
            await response.json();


        console.log(
            "Register response:",
            result
        );


        if (!response.ok) {

            showMessage(
                result.message ||
                result.error ||
                "Registration failed.",
                "error"
            );

            return;
        }


        /* =========================
           SUCCESS
        ========================= */

        showMessage(
            "Account created successfully! Redirecting to login...",
            "success"
        );


        form.reset();


        setTimeout(
            function () {

                window.location.href =
                    "login.html";

            },
            1500
        );

    }
    catch (error) {

        console.error(
            "Registration error:",
            error
        );


        showMessage(
            "Unable to connect to the API. Make sure the FinancePro API is running.",
            "error"
        );

    }

});


/* =========================
   MESSAGE
========================= */

function showMessage(
    text,
    type
) {

    message.textContent = text;

    message.className =
        `message ${type}`;

}