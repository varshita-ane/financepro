const API_URL =
    "http://localhost:5102/api";


const USER_ID = 1;


const money = (value) => {

    return "₹" +
        Number(value || 0).toLocaleString(
            "en-IN",
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

};



/* =====================================================
   API
===================================================== */

async function api(endpoint, options = {}) {

    const response =
        await fetch(
            API_URL + endpoint,
            {
                ...options,

                headers: {
                    "Content-Type":
                        "application/json",

                    ...(options.headers || {})
                }
            }
        );


    const text =
        await response.text();


    let data = {};


    try {

        data =
            text
                ? JSON.parse(text)
                : {};

    }
    catch {

        data = {};

    }


    if (!response.ok) {

        throw new Error(
            data.error ||
            text ||
            "Request failed"
        );

    }


    return data;

}



/* =====================================================
   DEFAULT DATE
===================================================== */

const today =
    new Date()
        .toISOString()
        .slice(0, 10);


document.getElementById(
    "incomeDate"
).value = today;


document.getElementById(
    "expenseDate"
).value = today;



/* =====================================================
   LOAD DATA
===================================================== */

async function loadTransactions() {

    try {

        const incomes =
            await api(
                `/Income?userId=${USER_ID}`
            );


        const expenses =
            await api(
                `/Expense?userId=${USER_ID}`
            );


        /* ================= TOTALS ================= */

        const totalIncome =
            incomes.reduce(
                (sum, item) =>
                    sum +
                    Number(item.amount || 0),
                0
            );


        const totalExpense =
            expenses.reduce(
                (sum, item) =>
                    sum +
                    Number(item.amount || 0),
                0
            );


        const balance =
            totalIncome -
            totalExpense;


        document.getElementById(
            "totalIncome"
        ).textContent =
            money(totalIncome);


        document.getElementById(
            "totalExpense"
        ).textContent =
            money(totalExpense);


        document.getElementById(
            "totalBalance"
        ).textContent =
            money(balance);



        /* ================= INCOME LIST ================= */

        const incomeList =
            document.getElementById(
                "incomeList"
            );


        if (incomes.length === 0) {

            incomeList.innerHTML =
                `<p class="loading">
                    No income records yet.
                </p>`;

        }
        else {

            incomeList.innerHTML =
                incomes
                    .slice()
                    .reverse()
                    .map(item => {

                        return `
                            <div class="transaction">

                                <div
                                    class="transaction-info">

                                    <strong>
                                        ${item.source ||
                                        "Income"}
                                    </strong>

                                    <span>
                                        ${item.category ||
                                        "Income"}
                                        ·
                                        ${new Date(
                                            item.date
                                        ).toLocaleDateString(
                                            "en-IN"
                                        )}
                                    </span>

                                </div>


                                <div
                                    class="transaction-right">

                                    <strong
                                        class="transaction-amount income-amount">

                                        +${money(
                                            item.amount
                                        )}

                                    </strong>

                                </div>

                            </div>
                        `;

                    })
                    .join("");

        }



        /* ================= EXPENSE LIST ================= */

        const expenseList =
            document.getElementById(
                "expenseList"
            );


        if (expenses.length === 0) {

            expenseList.innerHTML =
                `<p class="loading">
                    No expense records yet.
                </p>`;

        }
        else {

            expenseList.innerHTML =
                expenses
                    .slice()
                    .reverse()
                    .map(item => {

                        return `
                            <div class="transaction">

                                <div
                                    class="transaction-info">

                                    <strong>
                                        ${item.description ||
                                        "Expense"}
                                    </strong>

                                    <span>
                                        ${item.category ||
                                        "Other"}
                                        ·
                                        ${item.type ||
                                        "Need"}
                                        ·
                                        ${new Date(
                                            item.date
                                        ).toLocaleDateString(
                                            "en-IN"
                                        )}
                                    </span>

                                </div>


                                <div
                                    class="transaction-right">

                                    <strong
                                        class="transaction-amount expense-amount">

                                        -${money(
                                            item.amount
                                        )}

                                    </strong>


                                    <button
                                        class="delete-btn"
                                        onclick="deleteExpense(${item.id})">

                                        Delete

                                    </button>

                                </div>

                            </div>
                        `;

                    })
                    .join("");

        }

    }
    catch (error) {

        console.error(error);

        alert(
            "Unable to load data. " +
            "Make sure the API is running."
        );

    }

}



/* =====================================================
   ADD INCOME
===================================================== */

document
    .getElementById("incomeForm")
    .addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            try {

                await api(
                    "/Income",
                    {
                        method: "POST",

                        body: JSON.stringify({

                            userId:
                                USER_ID,

                            source:
                                document
                                    .getElementById(
                                        "incomeSource"
                                    )
                                    .value,

                            amount:
                                Number(
                                    document
                                        .getElementById(
                                            "incomeAmount"
                                        )
                                        .value
                                ),

                            category:
                                document
                                    .getElementById(
                                        "incomeCategory"
                                    )
                                    .value,

                            date:
                                document
                                    .getElementById(
                                        "incomeDate"
                                    )
                                    .value

                        })
                    }
                );


                event.target.reset();


                document.getElementById(
                    "incomeDate"
                ).value = today;


                await loadTransactions();


                alert(
                    "Income added successfully."
                );

            }
            catch (error) {

                alert(error.message);

            }

        }
    );



/* =====================================================
   ADD EXPENSE
===================================================== */

document
    .getElementById("expenseForm")
    .addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            try {

                await api(
                    "/Expense",
                    {
                        method: "POST",

                        body: JSON.stringify({

                            userId:
                                USER_ID,

                            description:
                                document
                                    .getElementById(
                                        "expenseDescription"
                                    )
                                    .value,

                            amount:
                                Number(
                                    document
                                        .getElementById(
                                            "expenseAmount"
                                        )
                                        .value
                                ),

                            category:
                                document
                                    .getElementById(
                                        "expenseCategory"
                                    )
                                    .value,

                            type:
                                document
                                    .getElementById(
                                        "expenseType"
                                    )
                                    .value,

                            date:
                                document
                                    .getElementById(
                                        "expenseDate"
                                    )
                                    .value

                        })
                    }
                );


                event.target.reset();


                document.getElementById(
                    "expenseDate"
                ).value = today;


                await loadTransactions();


                alert(
                    "Expense added successfully."
                );

            }
            catch (error) {

                alert(error.message);

            }

        }
    );



/* =====================================================
   DELETE EXPENSE
===================================================== */

async function deleteExpense(id) {

    const confirmed =
        confirm(
            "Delete this expense?"
        );


    if (!confirmed) {

        return;

    }


    try {

        await api(
            `/Expense/${id}`,
            {
                method: "DELETE"
            }
        );


        await loadTransactions();

    }
    catch (error) {

        alert(error.message);

    }

}



/* =====================================================
   INITIAL LOAD
===================================================== */

loadTransactions();