const API_URL = "http://localhost:5102/api";

const form = document.getElementById("loginForm");
const message = document.getElementById("message");

form.addEventListener("submit", async function (event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    if (!email || !password) {
        showMessage("Please enter email and password.", "error");
        return;
    }

    const data = {
        email: email,
        password: password
    };

    try {
        const response = await fetch(`${API_URL}/Auth/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        console.log("Login response:", result);

        if (!response.ok) {
            showMessage(
                result.message || "Invalid email or password.",
                "error"
            );
            return;
        }

        // Save logged-in user information
        localStorage.setItem("token", result.token);
        localStorage.setItem("userId", result.userId);
        localStorage.setItem("userName", result.name);
        localStorage.setItem("userEmail", result.email);
        localStorage.setItem("isLoggedIn", "true");

        showMessage(
            "Login successful! Redirecting...",
            "success"
        );

        setTimeout(function () {
            window.location.href = "dashboard.html";
        }, 1000);

    } catch (error) {
        console.error("Login error:", error);

        showMessage(
            "Unable to connect to the API. Make sure the FinancePro API is running.",
            "error"
        );
    }
});

function showMessage(text, type) {
    message.textContent = text;
    message.className = `message ${type}`;
}
