const API_URL = "http://localhost:5102/api";

const USER_ID = localStorage.getItem("userId");
const TOKEN = localStorage.getItem("token");

if (!USER_ID || !TOKEN) {
    window.location.href = "login.html";
}

const form = document.getElementById("incomeForm");
const list = document.getElementById("incomeList");


// =========================
// MONEY FORMAT
// =========================

function money(amount) {

    return "₹" + Number(amount || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });

}


// =========================
// DATE FORMAT
// =========================

function formatDate(date) {

    if (!date) return "";

    const d = new Date(date);

    if (isNaN(d)) return date;

    return d.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });

}


// =========================
// LOAD INCOME
// =========================

async function loadIncome() {

    try {

        const response = await fetch(
            `${API_URL}/Income`,
            {
                method: "GET",

                headers: {
                    "Authorization": "Bearer " + TOKEN
                }
            }
        );


        if (response.status === 401) {

            localStorage.removeItem("token");

            window.location.href = "login.html";

            return;
        }


        if (!response.ok) {
            throw new Error("Failed to load income");
        }


        const incomes = await response.json();


        const total = incomes.reduce(
            (sum, item) =>
                sum + Number(item.amount || 0),
            0
        );


        document.getElementById(
            "totalIncome"
        ).textContent = money(total);


        document.getElementById(
            "incomeCount"
        ).textContent = incomes.length;


        renderIncome(incomes);

    }
    catch (error) {

        console.error(error);

        list.innerHTML = `
            <div class="empty-state">
                Unable to load income data.
            </div>
        `;

    }

}


// =========================
// RENDER INCOME
// =========================

function renderIncome(incomes) {

    if (!incomes.length) {

        list.innerHTML = `
            <div class="empty-state">
                No income entries yet.
            </div>
        `;

        return;
    }


    const sorted = [...incomes].sort(
        (a, b) =>
            new Date(b.date) -
            new Date(a.date)
    );


    list.innerHTML = sorted.map(item => `

        <div class="income-item">

            <div class="income-left">

                <div class="income-icon">
                    ↑
                </div>

                <div class="income-details">

                    <strong>
                        ${escapeHtml(item.source || "Income")}
                    </strong>

                    <span>
                        ${escapeHtml(item.category || "Other")}
                        •
                        ${formatDate(item.date)}
                    </span>

                </div>

            </div>


            <div class="income-right">

                <strong>
                    +${money(item.amount)}
                </strong>

                <span>
                    Income
                </span>

            </div>

        </div>

    `).join("");

}


// =========================
// ADD INCOME
// =========================

form.addEventListener("submit", async function(event) {

    event.preventDefault();


    const data = {

        source:
            document.getElementById(
                "incomeSource"
            ).value.trim(),

        amount:
            Number(
                document.getElementById(
                    "incomeAmount"
                ).value
            ),

        category:
            document.getElementById(
                "incomeCategory"
            ).value,

        date:
            document.getElementById(
                "incomeDate"
            ).value

    };


    try {

        const response = await fetch(
            `${API_URL}/Income`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + TOKEN
                },

                body: JSON.stringify(data)
            }
        );


        if (response.status === 401) {

            localStorage.removeItem("token");

            window.location.href = "login.html";

            return;
        }


        if (!response.ok) {

            const error =
                await response.text();

            throw new Error(error);
        }


        alert("Income added successfully!");


        form.reset();


        setToday();


        loadIncome();

    }
    catch (error) {

        console.error(error);

        alert(
            "Unable to add income. " +
            "Please check the API."
        );

    }

});


// =========================
// SET TODAY
// =========================

function setToday() {

    const today =
        new Date().toISOString().split("T")[0];

    document.getElementById(
        "incomeDate"
    ).value = today;

}


// =========================
// ESCAPE HTML
// =========================

function escapeHtml(text) {

    return String(text).replace(
        /[&<>"']/g,
        char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[char])
    );

}


// =========================
// LOGOUT
// =========================

function logout() {

    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("token");

    window.location.href = "login.html";
}


// =========================
// INITIAL LOAD
// =========================

setToday();

loadIncome();