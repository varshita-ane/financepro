const API_URL = "http://localhost:5102/api";

const USER_ID = localStorage.getItem("userId");
const TOKEN = localStorage.getItem("token");

if (!USER_ID || !TOKEN) {
    window.location.href = "login.html";
}


// =========================
// COLORS FOR CATEGORIES
// =========================

const categoryColors = [
    "#4f46e5",
    "#ef4444",
    "#f59e0b",
    "#16a34a",
    "#8b5cf6",
    "#06b6d4",
    "#ec4899",
    "#64748b"
];


// =========================
// MONEY FORMAT
// =========================

function money(amount) {
    return "₹" + Number(amount || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}


// =========================
// LOAD EXPENSES
// =========================

async function loadSpendings() {

    try {

        const response = await fetch(
            `${API_URL}/Expense`,
            {
                method: "GET",
                headers: {
                    "Authorization": "Bearer " + TOKEN
                }
            }
        );


        if (response.status === 401) {
            localStorage.removeItem("token");
            localStorage.removeItem("userId");
            localStorage.removeItem("userName");
            localStorage.removeItem("userEmail");
            localStorage.removeItem("isLoggedIn");

            window.location.href = "login.html";
            return;
        }


        if (!response.ok) {
            throw new Error("Unable to load expenses");
        }


        const expenses = await response.json();


        updateSummary(expenses);

        createCategoryAnalysis(expenses);

        createRecentSpendings(expenses);

    }

    catch (error) {

        console.error("Spendings error:", error);

        document.getElementById("spendingList").innerHTML = `
            <div class="empty-state">
                Unable to load spending data.
                <br>
                Make sure the API is running.
            </div>
        `;

    }

}


// =========================
// SUMMARY
// =========================

function updateSummary(expenses) {

    const total =
        expenses.reduce(
            (sum, expense) =>
                sum + Number(expense.amount || 0),
            0
        );


    const count =
        expenses.length;


    const average =
        count > 0
            ? total / count
            : 0;


    document.getElementById(
        "totalSpending"
    ).textContent = money(total);


    document.getElementById(
        "transactionCount"
    ).textContent = count;


    document.getElementById(
        "averageSpending"
    ).textContent = money(average);


    document.getElementById(
        "donutTotal"
    ).textContent = money(total);


    return total;

}


// =========================
// CATEGORY ANALYSIS
// =========================

function createCategoryAnalysis(expenses) {

    const categories = {};


    expenses.forEach(expense => {

        const category =
            expense.category ||
            "Other";


        const amount =
            Number(expense.amount || 0);


        if (!categories[category]) {

            categories[category] = 0;

        }


        categories[category] += amount;

    });


    const sortedCategories =
        Object.entries(categories)
            .sort((a, b) => b[1] - a[1]);


    const total =
        sortedCategories.reduce(
            (sum, item) => sum + item[1],
            0
        );


    if (sortedCategories.length === 0) {

        document.getElementById(
            "categoryBars"
        ).innerHTML = `
            <div class="empty-state">
                No spending data available.
            </div>
        `;


        document.getElementById(
            "categoryLegend"
        ).innerHTML = "";

        return;

    }


    // Largest category

    document.getElementById(
        "largestCategory"
    ).textContent =
        sortedCategories[0][0];


    // Create donut

    createDonut(
        sortedCategories,
        total
    );


    // Create bars

    createCategoryBars(
        sortedCategories,
        total
    );

}


// =========================
// DONUT CHART
// =========================

function createDonut(categories, total) {

    let currentDegree = 0;

    const gradients = [];

    const legendHTML = [];


    categories.forEach(
        ([category, amount], index) => {

            const percentage =
                total > 0
                    ? amount / total
                    : 0;


            const degree =
                percentage * 360;


            const color =
                categoryColors[
                    index % categoryColors.length
                ];


            const start =
                currentDegree;


            const end =
                currentDegree + degree;


            gradients.push(
                `${color} ${start}deg ${end}deg`
            );


            currentDegree = end;


            legendHTML.push(`

                <div class="legend-item">

                    <span
                        class="legend-color"
                        style="background:${color}">
                    </span>

                    <span class="legend-name">
                        ${escapeHtml(category)}
                    </span>

                    <span class="legend-value">
                        ${percentage.toFixed(1)}%
                    </span>

                </div>

            `);

        }
    );


    document.getElementById(
        "donutChart"
    ).style.background =
        `conic-gradient(${gradients.join(",")})`;


    document.getElementById(
        "categoryLegend"
    ).innerHTML =
        legendHTML.join("");

}


// =========================
// CATEGORY BARS
// =========================

function createCategoryBars(categories, total) {

    const container =
        document.getElementById(
            "categoryBars"
        );


    container.innerHTML = "";


    categories.forEach(
        ([category, amount], index) => {

            const percentage =
                total > 0
                    ? (amount / total) * 100
                    : 0;


            const color =
                categoryColors[
                    index % categoryColors.length
                ];


            const row =
                document.createElement("div");


            row.className =
                "category-row";


            row.innerHTML = `

                <div class="category-info">

                    <span class="category-name">
                        ${escapeHtml(category)}
                    </span>

                    <span class="category-amount">
                        ${money(amount)}
                    </span>

                </div>


                <div class="progress-track">

                    <div
                        class="progress-bar"
                        style="
                            width:${percentage}%;
                            background:${color};
                        ">
                    </div>

                </div>


                <span class="category-percent">

                    ${percentage.toFixed(1)}%
                    of total spending

                </span>

            `;


            container.appendChild(row);

        }
    );

}


// =========================
// RECENT SPENDING
// =========================

function createRecentSpendings(expenses) {

    const container =
        document.getElementById(
            "spendingList"
        );


    if (!expenses.length) {

        container.innerHTML = `
            <div class="empty-state">
                No expenses recorded yet.
            </div>
        `;

        return;

    }


    // Newest first

    const sorted =
        [...expenses].sort(
            (a, b) =>
                new Date(b.date) -
                new Date(a.date)
        );


    const recent =
        sorted.slice(0, 10);


    container.innerHTML = "";


    recent.forEach(expense => {

        const category =
            expense.category ||
            "Other";


        const item =
            document.createElement("div");


        item.className =
            "spending-item";


        item.innerHTML = `

            <div class="spending-left">

                <div class="spending-icon">
                    ↓
                </div>

                <div class="spending-details">

                    <strong>
                        ${escapeHtml(
                            expense.description ||
                            "Expense"
                        )}
                    </strong>

                    <span>
                        ${escapeHtml(category)}
                        •
                        ${formatDate(expense.date)}
                    </span>

                </div>

            </div>


            <div class="spending-right">

                <strong>
                    -${money(expense.amount)}
                </strong>

                <span>
                    ${escapeHtml(
                        expense.type ||
                        "Expense"
                    )}
                </span>

            </div>

        `;


        container.appendChild(item);

    });

}


// =========================
// DATE FORMAT
// =========================

function formatDate(date) {

    if (!date) {
        return "";
    }


    const d =
        new Date(date);


    if (isNaN(d)) {
        return date;
    }


    return d.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


// =========================
// ESCAPE HTML
// =========================

function escapeHtml(text) {

    return String(text).replace(
        /[&<>"']/g,
        function (char) {

            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[char];

        }
    );

}


// =========================
// START
// =========================

loadSpendings();


// =========================
// LOGOUT
// =========================

function logout() {

    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("token");

    window.location.href = "login.html";
}