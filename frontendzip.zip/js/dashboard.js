const API_URL = "http://localhost:5102/api";

const USER_ID = localStorage.getItem("userId");
const TOKEN = localStorage.getItem("token");

if (!USER_ID || !TOKEN) {
    window.location.href = "login.html";
}


/* =========================
   HELPERS
========================= */

function money(amount) {
    return "₹" + Number(amount || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}


function formatDate(date) {

    if (!date) return "";

    const d = new Date(date);

    if (isNaN(d.getTime())) {
        return date;
    }

    return d.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}


function escapeHtml(text) {

    return String(text || "").replace(
        /[&<>"']/g,
        function (char) {

            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[char];

        }
    );
}


/* =========================
   LOAD DASHBOARD
========================= */

async function loadDashboard() {

    try {

        console.log("Loading dashboard...");


        /* =========================
           LOAD INCOME
        ========================= */

        const incomeResponse = await fetch(
            `${API_URL}/Income`,
            {
                method: "GET",

                headers: {
                    "Authorization": "Bearer " + TOKEN
                }
            }
        );


        if (incomeResponse.status === 401) {

            localStorage.removeItem("token");

            window.location.href = "login.html";

            return;
        }


        if (!incomeResponse.ok) {

            throw new Error(
                `Income API Error: ${incomeResponse.status}`
            );

        }


        const incomes = await incomeResponse.json();


        /* =========================
           LOAD EXPENSES
        ========================= */

        const expenseResponse = await fetch(
    `${API_URL}/Expense`,
    {
        method: "GET",
        headers: {
            "Authorization": "Bearer " + TOKEN
        }
    }
);

        if (!expenseResponse.ok) {

            throw new Error(
                `Expense API Error: ${expenseResponse.status}`
            );

        }


        const expenses = await expenseResponse.json();


        console.log("Income:", incomes);
        console.log("Expenses:", expenses);


        /* =========================
           CALCULATE TOTALS
        ========================= */

        const totalIncome = incomes.reduce(
            (sum, income) =>
                sum + Number(income.amount || 0),
            0
        );


        const totalExpenses = expenses.reduce(
            (sum, expense) =>
                sum + Number(expense.amount || 0),
            0
        );


        const balance =
            totalIncome - totalExpenses;


        let savingsRate = 0;

        if (totalIncome > 0) {

            savingsRate =
                (balance / totalIncome) * 100;

        }


        /* =========================
           SUMMARY CARDS
        ========================= */

        document.getElementById(
            "income"
        ).textContent = money(totalIncome);


        document.getElementById(
            "expenses"
        ).textContent = money(totalExpenses);


        document.getElementById(
            "balance"
        ).textContent = money(balance);


        document.getElementById(
            "savingsRate"
        ).textContent =
            `${Math.max(0, savingsRate).toFixed(1)}%`;


        /* =========================
           FINANCIAL HEALTH
        ========================= */

        document.getElementById(
            "healthIncome"
        ).textContent = money(totalIncome);


        document.getElementById(
            "healthExpense"
        ).textContent = money(totalExpenses);


        document.getElementById(
            "healthSavings"
        ).textContent = money(balance);


        updateHealthMessage(
            totalIncome,
            totalExpenses,
            balance,
            savingsRate
        );


        /* =========================
           CATEGORY ANALYSIS
        ========================= */

        renderCategories(expenses);


        /* =========================
           RECENT TRANSACTIONS
        ========================= */

        renderRecentTransactions(
            incomes,
            expenses
        );


        /* =========================
           AI-STYLE INSIGHT
        ========================= */

        generateInsight(
            totalIncome,
            totalExpenses,
            balance,
            savingsRate,
            expenses
        );

    }
    catch (error) {

        console.error(
            "Dashboard loading error:",
            error
        );

        showDashboardError(error.message);

    }

}


/* =========================
   FINANCIAL HEALTH MESSAGE
========================= */

function updateHealthMessage(
    income,
    expenses,
    balance,
    savingsRate
) {

    const message =
        document.getElementById(
            "healthMessage"
        );


    if (income === 0 && expenses === 0) {

        message.textContent =
            "Start adding your income and expenses to see your financial health.";

        return;
    }


    if (balance < 0) {

        message.textContent =
            "Your expenses are currently higher than your income. Consider reducing unnecessary spending.";

        return;
    }


    if (savingsRate >= 30) {

        message.textContent =
            `You are saving ${savingsRate.toFixed(1)}% of your income. Keep maintaining this healthy balance.`;

        return;
    }


    if (savingsRate >= 20) {

        message.textContent =
            `You are saving ${savingsRate.toFixed(1)}% of your income. Try to gradually increase your savings.`;

        return;
    }


    if (savingsRate > 0) {

        message.textContent =
            `You currently save ${savingsRate.toFixed(1)}% of your income. Consider setting a higher monthly savings target.`;

        return;
    }


    message.textContent =
        "Your income is currently fully used by expenses. Consider reviewing your spending.";
}


/* =========================
   CATEGORY ANALYSIS
========================= */

function renderCategories(expenses) {

    const categoryList =
        document.getElementById(
            "categoryList"
        );


    if (!expenses || expenses.length === 0) {

        categoryList.innerHTML = `
            <div class="empty-state">
                No spending data available yet.
            </div>
        `;

        return;
    }


    const categories = {};


    expenses.forEach(expense => {

        const category =
            expense.category ||
            "Other";

        const amount =
            Number(expense.amount || 0);


        if (!categories[category]) {

            categories[category] = 0;

        }


        categories[category] += amount;

    });


    const total =
        Object.values(categories)
            .reduce(
                (sum, amount) =>
                    sum + amount,
                0
            );


    const sortedCategories =
        Object.entries(categories)
            .sort(
                (a, b) =>
                    b[1] - a[1]
            );


    categoryList.innerHTML = "";


    sortedCategories.forEach(
        ([category, amount]) => {

            const percentage =
                total > 0
                    ? (amount / total) * 100
                    : 0;


            const item =
                document.createElement("div");

            item.className =
                "category-item";


            item.innerHTML = `

                <div class="category-info">

                    <span class="category-name">
                        ${escapeHtml(category)}
                    </span>

                    <span class="category-amount">
                        ${money(amount)}
                    </span>

                </div>


                <div class="category-progress">

                    <div
                        class="category-progress-bar"
                        style="width: ${percentage}%">
                    </div>

                </div>


                <span class="category-percent">
                    ${percentage.toFixed(1)}% of total spending
                </span>

            `;


            categoryList.appendChild(item);

        }
    );

}


/* =========================
   RECENT TRANSACTIONS
========================= */

function renderRecentTransactions(
    incomes,
    expenses
) {

    const container =
        document.getElementById(
            "transactions"
        );


    const transactions = [];


    /* INCOME */

    incomes.forEach(income => {

        transactions.push({

            type: "income",

            description:
                income.source ||
                "Income",

            amount:
                Number(income.amount || 0),

            date:
                income.date,

            category:
                income.category ||
                "Income"

        });

    });


    /* EXPENSE */

    expenses.forEach(expense => {

        transactions.push({

            type: "expense",

            description:
                expense.description ||
                "Expense",

            amount:
                Number(expense.amount || 0),

            date:
                expense.date,

            category:
                expense.type ||
                "Expense"

        });

    });


    /* SORT BY DATE */

    transactions.sort(
        (a, b) =>
            new Date(b.date) -
            new Date(a.date)
    );


    /* ONLY 6 RECENT */

    const recent =
        transactions.slice(0, 6);


    if (recent.length === 0) {

        container.innerHTML = `
            <div class="empty-state">
                No transactions yet.
            </div>
        `;

        return;
    }


    container.innerHTML = "";


    recent.forEach(transaction => {

        const item =
            document.createElement("div");


        item.className =
            "transaction-item";


        const isIncome =
            transaction.type === "income";


        const sign =
            isIncome ? "+" : "-";


        item.innerHTML = `

            <div class="transaction-left">

                <div class="
                    transaction-icon
                    ${isIncome ? "income" : "expense"}
                ">

                    ${isIncome ? "↑" : "↓"}

                </div>


                <div class="transaction-details">

                    <strong>
                        ${escapeHtml(
                            transaction.description
                        )}
                    </strong>

                    <span>
                        ${escapeHtml(
                            transaction.category
                        )}
                        •
                        ${formatDate(
                            transaction.date
                        )}
                    </span>

                </div>

            </div>


            <div class="transaction-right">

                <strong class="
                    ${isIncome ? "income" : "expense"}
                ">

                    ${sign}${money(
                        transaction.amount
                    )}

                </strong>

                <span>
                    ${isIncome
                        ? "Income"
                        : "Expense"}
                </span>

            </div>

        `;


        container.appendChild(item);

    });

}


/* =========================
   LOCAL FINANCE INSIGHT
========================= */

function generateInsight(
    income,
    expenses,
    balance,
    savingsRate,
    expenseList
) {

    const insight =
        document.getElementById(
            "insight"
        );


    if (income === 0 && expenses === 0) {

        insight.textContent =
            "Add your income and expenses to receive personalized financial insights.";

        return;
    }


    if (balance < 0) {

        insight.textContent =
            `Your expenses exceed your income by ${money(
                Math.abs(balance)
            )}. Review your recent spending and reduce non-essential expenses.`;

        return;
    }


    if (savingsRate >= 30) {

        insight.textContent =
            `You currently have ${money(
                balance
            )} left after expenses and a savings rate of ${savingsRate.toFixed(
                1
            )}%.`;

        return;
    }


    if (savingsRate >= 20) {

        insight.textContent =
            `You have ${money(
                balance
            )} remaining after expenses. Consider setting aside part of it as savings.`;

        return;
    }


    if (expenses > 0 && income > 0) {

        const spendingPercentage =
            (expenses / income) * 100;


        insight.textContent =
            `Your expenses currently use ${spendingPercentage.toFixed(
                1
            )}% of your income. Tracking your largest spending categories can help you manage your budget.`;

        return;
    }


    insight.textContent =
        `Your current balance is ${money(
            balance
        )}. Keep tracking your financial activity regularly.`;

}


/* =========================
   ERROR MESSAGE
========================= */

function showDashboardError(message) {

    document.getElementById(
        "categoryList"
    ).innerHTML = `
        <div class="empty-state">
            Unable to load spending data.
            <br><br>
            ${escapeHtml(message)}
        </div>
    `;


    document.getElementById(
        "transactions"
    ).innerHTML = `
        <div class="empty-state">
            Unable to load transactions.
            <br><br>
            ${escapeHtml(message)}
        </div>
    `;


    document.getElementById(
        "healthMessage"
    ).textContent =
        "Unable to load financial data. Make sure the FinancePro API is running.";
}


/* =========================
   START DASHBOARD
========================= */

loadDashboard();


/* =========================
   LOGOUT
========================= */

function logout() {

    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("token");

    window.location.href = "login.html";
}