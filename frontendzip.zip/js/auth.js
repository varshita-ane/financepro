// =========================
// AUTHENTICATION HELPER
// =========================

function getUserId() {
    return localStorage.getItem("userId");
}

function getUserName() {
    return localStorage.getItem("userName");
}

function getUserEmail() {
    return localStorage.getItem("userEmail");
}

function isLoggedIn() {
    return localStorage.getItem("isLoggedIn") === "true"
        && getUserId() !== null;
}


// =========================
// PROTECT PAGE
// =========================

function requireLogin() {
    if (!isLoggedIn()) {
        window.location.href = "login.html";
        return false;
    }

    return true;
}


// =========================
// LOGOUT
// =========================

function logout() {
    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("isLoggedIn");

    window.location.href = "login.html";
}