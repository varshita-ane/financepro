const API_URL = "http://localhost:5102/api";

const USER_ID = localStorage.getItem("userId");
const TOKEN = localStorage.getItem("token");

if (!USER_ID || !TOKEN) {
    window.location.href = "login.html";
}


/* =========================
   ELEMENTS
========================= */

const form =
    document.getElementById("expenseForm");

const list =
    document.getElementById("expenseList");


/* =========================
   MONEY FORMAT
========================= */

function money(amount) {

    return "₹" +
        Number(amount || 0).toLocaleString(
            "en-IN",
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

}


/* =========================
   DATE FORMAT
========================= */

function formatDate(date) {

    if (!date) return "";

    const d = new Date(date);

    if (isNaN(d.getTime())) {
        return date;
    }

    return d.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


/* =========================
   LOAD EXPENSES
========================= */

async function loadExpenses() {

    try {

        console.log("Loading expenses...");


        const response =
            await fetch(
                `${API_URL}/Expense`,
                {
                    method: "GET",

                    headers: {
                        "Authorization": "Bearer " + TOKEN
                    }
                }
            );


        console.log(
            "Response status:",
            response.status
        );


        if (response.status === 401) {

            localStorage.removeItem("token");

            window.location.href = "login.html";

            return;
        }


        if (!response.ok) {

            const errorText =
                await response.text();

            throw new Error(
                `API Error ${response.status}: ${errorText}`
            );

        }


        const expenses =
            await response.json();


        console.log(
            "Expenses:",
            expenses
        );


        /* =========================
           TOTAL
        ========================= */

        const total =
            expenses.reduce(
                (sum, expense) =>
                    sum +
                    Number(
                        expense.amount || 0
                    ),
                0
            );


        document.getElementById(
            "totalExpense"
        ).textContent =
            money(total);


        /* =========================
           COUNT
        ========================= */

        document.getElementById(
            "expenseCount"
        ).textContent =
            expenses.length;


        /* =========================
           RENDER
        ========================= */

        renderExpenses(expenses);

    }
    catch (error) {

        console.error(
            "Expense loading error:",
            error
        );


        list.innerHTML = `

            <div class="empty-state">

                Unable to load expenses.

                <br><br>

                ${escapeHtml(
                    error.message
                )}

            </div>

        `;

    }

}


/* =========================
   RENDER EXPENSES
========================= */

function renderExpenses(expenses) {

    if (
        !expenses ||
        expenses.length === 0
    ) {

        list.innerHTML = `

            <div class="empty-state">

                No expense entries yet.

            </div>

        `;

        return;

    }


    /* NEWEST FIRST */

    const sortedExpenses =
        [...expenses].sort(
            (a, b) =>
                new Date(b.date) -
                new Date(a.date)
        );


    list.innerHTML = "";


    sortedExpenses.forEach(
        expense => {

            const item =
                document.createElement(
                    "div"
                );


            item.className =
                "expense-item";


            item.innerHTML = `

                <div class="expense-left">

                    <div class="expense-icon">
                        ↓
                    </div>


                    <div class="expense-details">

                        <strong>
                            ${escapeHtml(
                                expense.description ||
                                "Expense"
                            )}
                        </strong>


                        <span>

                            ${escapeHtml(
                                expense.category ||
                                "Other"
                            )}

                            •

                            ${escapeHtml(
                                expense.type ||
                                "Expense"
                            )}

                            •

                            ${formatDate(
                                expense.date
                            )}

                        </span>

                    </div>

                </div>


                <div class="expense-right">

                    <strong>
                        -${money(
                            expense.amount
                        )}
                    </strong>

                    <span>
                        Expense
                    </span>

                </div>

            `;


            list.appendChild(item);

        }
    );

}


/* =========================
   ADD EXPENSE
========================= */

form.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();


        /* =========================
           GET FORM VALUES
        ========================= */

        const description =
            document.getElementById(
                "expenseDescription"
            ).value.trim();


        const amount =
            Number(
                document.getElementById(
                    "expenseAmount"
                ).value
            );


        const category =
            document.getElementById(
                "expenseCategory"
            ).value;


        const type =
            document.getElementById(
                "expenseType"
            ).value;


        const date =
            document.getElementById(
                "expenseDate"
            ).value;


        /* =========================
           VALIDATION
        ========================= */

        if (!description) {

            alert(
                "Please enter an expense description."
            );

            return;

        }


        if (!amount || amount <= 0) {

            alert(
                "Please enter a valid amount."
            );

            return;

        }


        if (!category) {

            alert(
                "Please select a category."
            );

            return;

        }


        if (!type) {

            alert(
                "Please select Need or Want."
            );

            return;

        }


        if (!date) {

            alert(
                "Please select a date."
            );

            return;

        }


        /* =========================
           API DATA
        ========================= */

        const data = {

            description:
                description,

            amount:
                amount,

            category:
                category,

            type:
                type,

            date:
                date

        };


        console.log(
            "Sending expense:",
            data
        );


        try {

            const response =
                await fetch(
                    `${API_URL}/Expense`,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            "Authorization":
                                "Bearer " + TOKEN
                        },

                        body:
                            JSON.stringify(data)
                    }
                );


            const responseText =
                await response.text();


            console.log(
                "POST status:",
                response.status
            );


            console.log(
                "POST response:",
                responseText
            );


            if (response.status === 401) {

                localStorage.removeItem("token");

                window.location.href = "login.html";

                return;
            }


            if (!response.ok) {

                throw new Error(
                    `API Error ${response.status}: ${responseText}`
                );

            }


            /* =========================
               SUCCESS
            ========================= */

            alert(
                "Expense added successfully!"
            );


            form.reset();


            setToday();


            await loadExpenses();

        }
        catch (error) {

            console.error(
                "Add expense error:",
                error
            );


            alert(
                "Unable to add expense.\n\n" +
                error.message
            );

        }

    }
);


/* =========================
   SET TODAY
========================= */

function setToday() {

    const today =
        new Date()
            .toISOString()
            .split("T")[0];


    document.getElementById(
        "expenseDate"
    ).value =
        today;

}


/* =========================
   ESCAPE HTML
========================= */

function escapeHtml(text) {

    return String(text || "")
        .replace(
            /[&<>"']/g,
            function (char) {

                return {

                    "&": "&amp;",

                    "<": "&lt;",

                    ">": "&gt;",

                    '"': "&quot;",

                    "'": "&#039;"

                }[char];

            }
        );

}


/* =========================
   LOGOUT
========================= */

function logout() {

    localStorage.removeItem("userId");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("token");

    window.location.href = "login.html";
}


/* =========================
   START
========================= */

setToday();

loadExpenses();