const API_URL = "http://localhost:5102/api";

const USER_ID = localStorage.getItem("userId");
const TOKEN = localStorage.getItem("token");

if (!USER_ID || !TOKEN) {
    window.location.href = "login.html";
}

const chat = document.getElementById("chat");
const form = document.getElementById("chatForm");
const input = document.getElementById("question");
const newChat = document.getElementById("newChat");

// =========================
// CHAT HISTORY
// =========================

let chatHistory = [];


// =========================
// MONEY FORMAT
// =========================

function money(amount) {
    return "₹" + Number(amount || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}


// =========================
// ESCAPE HTML
// =========================

function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, function (char) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[char];
    });
}


// =========================
// ADD MESSAGE TO UI
// =========================

function addMessageToUI(text, type) {

    const message = document.createElement("div");

    message.className =
        type === "user"
            ? "message user-message"
            : "message ai-message";


    if (type === "user") {

        message.innerHTML = `
            <div class="message-content">
                <p>
                    ${escapeHtml(text)}
                </p>

                <span class="message-time">
                    Just now
                </span>
            </div>
        `;

    } else {

        const formattedText =
            escapeHtml(text)
                .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
                .replace(/\n/g, "<br>");

        message.innerHTML = `
            <div class="message-avatar">
                ✨
            </div>

            <div class="message-content">
                <p>
                    ${formattedText}
                </p>

                <span class="message-time">
                    Just now
                </span>
            </div>
        `;
    }

    chat.appendChild(message);

    chat.scrollTop = chat.scrollHeight;

    return message;
}


// =========================
// ADD MESSAGE
// =========================

function addMessage(text, type) {

    const message = addMessageToUI(
        text,
        type
    );

    return message;
}


// =========================
// ASK GEMINI
// =========================

async function ask(question) {

    question = question.trim();

    if (!question) {
        return;
    }


    // =========================
    // ADD USER MESSAGE
    // =========================

    addMessage(
        question,
        "user"
    );


    // Store user message
    chatHistory.push({
        role: "user",
        content: question
    });


    // Clear input
    input.value = "";


    // =========================
    // LOADING MESSAGE
    // =========================

    const loading = addMessage(
        "Thinking...",
        "ai"
    );


    try {

        // =========================
        // SEND CHAT HISTORY
        // =========================

        const response = await fetch(
            `${API_URL}/AI/ask`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + TOKEN
                },

                body: JSON.stringify({
    question: question,

    chatHistory: chatHistory
        .slice(-10)
        .map(message => ({
            role: message.role,
            content: message.content
        }))
})
            }
        );


        // =========================
        // READ SERVER RESPONSE
        // =========================

        const responseText =
            await response.text();


        // Remove loading message
        loading.remove();


        let data = {};

        try {

            data = responseText
                ? JSON.parse(responseText)
                : {};

        } catch (parseError) {

            console.error(
                "AI server response:",
                responseText
            );

            addMessage(
                "AI server error. Please check the API terminal for the actual error.",
                "ai"
            );

            return;
        }


        // =========================
        // SERVER ERROR
        // =========================

        if (!response.ok) {

            addMessage(
                data.error ||
                data.message ||
                "Something went wrong while contacting Gemini.",
                "ai"
            );

            return;
        }


        // =========================
        // AI ANSWER
        // =========================

        const answer =
            data.answer ||
            "Gemini did not return an answer.";


        // Add AI message to UI
        addMessage(
            answer,
            "ai"
        );


        // Store AI response
        chatHistory.push({
            role: "model",
            content: answer
        });


    } catch (error) {

        console.error(
            "AI request error:",
            error
        );


        loading.remove();


        addMessage(
            "Unable to connect to the AI server. Make sure your API is running on port 5102.",
            "ai"
        );
    }
}


// =========================
// CHAT FORM
// =========================

form.addEventListener(
    "submit",
    function (event) {

        event.preventDefault();

        ask(input.value);

    }
);


// =========================
// SUGGESTED QUESTIONS
// =========================

document
    .querySelectorAll("[data-question]")
    .forEach(button => {

        button.addEventListener(
            "click",
            function () {

                ask(
                    button.dataset.question
                );

            }
        );

    });


// =========================
// NEW CHAT
// =========================

newChat.addEventListener(
    "click",
    function () {

        // Clear current conversation
        chatHistory = [];


        // Reset chat UI
        chat.innerHTML = `

            <div class="message ai-message">

                <div class="message-avatar">
                    ✨
                </div>

                <div class="message-content">

                    <p>
                        New chat started. 👋
                    </p>

                    <p>
                        What would you like to know
                        about your finances?
                    </p>

                    <span class="message-time">
                        Just now
                    </span>

                </div>

            </div>

        `;

        input.focus();

    }
);


// =========================
// LOAD FINANCIAL SNAPSHOT
// =========================

async function loadSnapshot() {

    try {

        const [
            incomeResponse,
            expenseResponse
        ] = await Promise.all([

            fetch(
                `${API_URL}/Income?userId=${USER_ID}`
            ),

            fetch(
                `${API_URL}/Expense?userId=${USER_ID}`
            )

        ]);


        const incomes =
            await incomeResponse.json();

        const expenses =
            await expenseResponse.json();


        // =========================
        // TOTAL INCOME
        // =========================

        const totalIncome =
            incomes.reduce(
                (sum, item) =>
                    sum + Number(item.amount || 0),
                0
            );


        // =========================
        // TOTAL EXPENSE
        // =========================

        const totalExpense =
            expenses.reduce(
                (sum, item) =>
                    sum + Number(item.amount || 0),
                0
            );


        // =========================
        // BALANCE
        // =========================

        const balance =
            totalIncome - totalExpense;


        // =========================
        // SAVINGS RATE
        // =========================

        const savingsRate =
            totalIncome > 0
                ? (balance / totalIncome) * 100
                : 0;


        // =========================
        // UPDATE SNAPSHOT
        // =========================

        document.getElementById(
            "snapIncome"
        ).textContent =
            money(totalIncome);


        document.getElementById(
            "snapExpense"
        ).textContent =
            money(totalExpense);


        document.getElementById(
            "snapBalance"
        ).textContent =
            money(balance);


        document.getElementById(
            "snapRate"
        ).textContent =
            `${savingsRate.toFixed(1)}%`;


    } catch (error) {

        console.error(
            "Snapshot error:",
            error
        );

    }
}


// =========================
// LOGOUT
// =========================

function logout() {

    localStorage.removeItem("userId");

    localStorage.removeItem("userName");

    localStorage.removeItem("userEmail");

    localStorage.removeItem("isLoggedIn");

    localStorage.removeItem("token");

    window.location.href = "login.html";
}


// =========================
// LOAD CHAT HISTORY FROM SQL
// =========================

async function loadChatFromSQL() {

    try {

        const response = await fetch(
            `${API_URL}/AI/history`,
            {
                method: "GET",

                headers: {
                    "Authorization": "Bearer " + TOKEN
                }
            }
        );


        if (!response.ok) {

            if (response.status === 401) {

                console.error(
                    "Unauthorized. Please login again."
                );

                localStorage.removeItem("token");

                window.location.href = "login.html";

                return;
            }

            throw new Error(
                "Failed to load chat history."
            );
        }


        const messages =
            await response.json();


        chatHistory = [];


        // Clear existing chat UI
        chat.innerHTML = "";


        messages.forEach(message => {

            chatHistory.push({
                role: message.role,
                content: message.content
            });


            addMessageToUI(
                message.content,
                message.role === "user"
                    ? "user"
                    : "ai"
            );

        });


        chat.scrollTop =
            chat.scrollHeight;


    } catch (error) {

        console.error(
            "Error loading chat history:",
            error
        );

    }
}


// =========================
// INITIAL LOAD
// =========================

loadChatFromSQL();
loadSnapshot();