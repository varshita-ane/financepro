using financepro.Api.Data;
using financepro.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;


namespace financepro.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly FinanceDbContext _context;

    public AuthController(FinanceDbContext context)
    {
        _context = context;
    }

    // =========================
    // REGISTER
    // =========================
    [HttpPost("register")]
    public async Task<IActionResult> Register(
        [FromBody] RegisterRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Name) ||
                string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest(new
                {
                    message = "Name, email and password are required."
                });
            }

            if (request.Password.Length < 6)
            {
                return BadRequest(new
                {
                    message = "Password must be at least 6 characters."
                });
            }

            var email = request.Email.Trim().ToLower();

            var existingUser =
                await _context.Users
                    .FirstOrDefaultAsync(
                        u => u.Email.ToLower() == email
                    );

            if (existingUser != null)
            {
                return BadRequest(new
                {
                    message = "An account with this email already exists."
                });
            }

            var passwordHash = HashPassword(request.Password);

            var user = new User
            {
                Name = request.Name.Trim(),
                Email = email,
                PasswordHash = passwordHash
            };

            _context.Users.Add(user);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Account created successfully.",
                userId = user.Id
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new
            {
                message = "Registration failed.",
                error = ex.Message
            });
        }
    }


    // =========================
    // LOGIN
    // =========================
    [HttpPost("login")]
    public async Task<IActionResult> Login(
        [FromBody] LoginRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest(new
                {
                    message = "Email and password are required."
                });
            }

            var email = request.Email.Trim().ToLower();

            var user =
                await _context.Users
                    .FirstOrDefaultAsync(
                        u => u.Email.ToLower() == email
                    );

            if (user == null)
            {
                return Unauthorized(new
                {
                    message = "Invalid email or password."
                });
            }

            bool passwordValid =
                VerifyPassword(
                    request.Password,
                    user.PasswordHash
                );

            if (!passwordValid)
            {
                return Unauthorized(new
                {
                    message = "Invalid email or password."
                });
            }

           var jwtKey = HttpContext.RequestServices
    .GetRequiredService<IConfiguration>()["Jwt:Key"];

if (string.IsNullOrWhiteSpace(jwtKey))
{
    return StatusCode(500, new
    {
        message = "JWT key is not configured."
    });
}

var claims = new[]
{
    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
    new Claim(ClaimTypes.Name, user.Name),
    new Claim(ClaimTypes.Email, user.Email)
};

var key = new SymmetricSecurityKey(
    Encoding.UTF8.GetBytes(jwtKey)
);

var credentials = new SigningCredentials(
    key,
    SecurityAlgorithms.HmacSha256
);

var token = new JwtSecurityToken(
    claims: claims,
    expires: DateTime.UtcNow.AddHours(8),
    signingCredentials: credentials
);

var tokenString = new JwtSecurityTokenHandler()
    .WriteToken(token);

return Ok(new
{
    message = "Login successful.",
    token = tokenString,
    userId = user.Id,
    name = user.Name,
    email = user.Email
});
        }
        catch (Exception ex)
        {
            return StatusCode(500, new
            {
                message = "Login failed.",
                error = ex.Message
            });
        }
    }


    // =========================
    // PASSWORD HASHING
    // =========================
    private static string HashPassword(string password)
    {
        byte[] salt =
            RandomNumberGenerator.GetBytes(16);

        byte[] hash =
            Rfc2898DeriveBytes.Pbkdf2(
                password,
                salt,
                100000,
                HashAlgorithmName.SHA256,
                32
            );

        return
            $"{Convert.ToBase64String(salt)}." +
            $"{Convert.ToBase64String(hash)}";
    }


    // =========================
    // PASSWORD VERIFICATION
    // =========================
    private static bool VerifyPassword(
        string password,
        string storedPassword)
    {
        try
        {
            var parts = storedPassword.Split('.');

            if (parts.Length != 2)
            {
                return false;
            }

            byte[] salt =
                Convert.FromBase64String(parts[0]);

            byte[] storedHash =
                Convert.FromBase64String(parts[1]);

            byte[] enteredHash =
                Rfc2898DeriveBytes.Pbkdf2(
                    password,
                    salt,
                    100000,
                    HashAlgorithmName.SHA256,
                    32
                );

            return CryptographicOperations.FixedTimeEquals(
                enteredHash,
                storedHash
            );
        }
        catch
        {
            return false;
        }
    }
}


// =========================
// REGISTER REQUEST
// =========================

public class RegisterRequest
{
    public string Name { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;
}


// =========================
// LOGIN REQUEST
// =========================

public class LoginRequest
{
    public string Email { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;
}