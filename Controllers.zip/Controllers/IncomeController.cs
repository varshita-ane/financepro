using financepro.Api.Data;
using financepro.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace financepro.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class IncomeController : ControllerBase
{
    private readonly FinanceDbContext _context;

    public IncomeController(FinanceDbContext context)
    {
        _context = context;
    }

    // =========================
    // GET INCOME
    // =========================

    [HttpGet]
    public async Task<IActionResult> GetIncome()
    {
        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        var incomes = await _context.Incomes
            .Where(i => i.UserId == userId.Value)
            .OrderByDescending(i => i.Date)
            .ToListAsync();

        return Ok(incomes);
    }

    // =========================
    // GET TOTAL INCOME
    // =========================

    [HttpGet("total")]
    public async Task<IActionResult> GetTotalIncome()
    {
        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        var total = await _context.Incomes
            .Where(i => i.UserId == userId.Value)
            .SumAsync(i => i.Amount);

        return Ok(new
        {
            totalIncome = total
        });
    }

    // =========================
    // ADD INCOME
    // =========================

    [HttpPost]
    public async Task<IActionResult> AddIncome(
        [FromBody] IncomeRequest request)
    {
        if (request == null)
        {
            return BadRequest(new
            {
                message = "Request is required."
            });
        }

        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        if (string.IsNullOrWhiteSpace(request.Source))
        {
            return BadRequest(new
            {
                message = "Income source is required."
            });
        }

        if (request.Amount <= 0)
        {
            return BadRequest(new
            {
                message = "Amount must be greater than zero."
            });
        }

        if (string.IsNullOrWhiteSpace(request.Category))
        {
            return BadRequest(new
            {
                message = "Category is required."
            });
        }

        var income = new Income
        {
            UserId = userId.Value,
            Source = request.Source.Trim(),
            Amount = request.Amount,
            Category = request.Category.Trim(),
            Description = request.Description?.Trim() ?? "",
            Date = request.Date
        };

        _context.Incomes.Add(income);

        await _context.SaveChangesAsync();

        return Ok(new
        {
            message = "Income added successfully.",
            income = income
        });
    }

    // =========================
    // DELETE INCOME
    // =========================

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteIncome(int id)
    {
        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        var income = await _context.Incomes
            .FirstOrDefaultAsync(i =>
                i.Id == id &&
                i.UserId == userId.Value);

        if (income == null)
        {
            return NotFound(new
            {
                message = "Income not found."
            });
        }

        _context.Incomes.Remove(income);

        await _context.SaveChangesAsync();

        return Ok(new
        {
            message = "Income deleted successfully."
        });
    }

    // =========================
    // GET USER ID FROM JWT
    // =========================

    private int? GetUserId()
    {
        var userIdClaim = User.FindFirst(
            System.Security.Claims.ClaimTypes.NameIdentifier
        );

        if (userIdClaim == null)
            return null;

        if (!int.TryParse(userIdClaim.Value, out int userId))
            return null;

        return userId;
    }
}


// =========================
// INCOME REQUEST
// =========================

public class IncomeRequest
{
    public string Source { get; set; } = string.Empty;

    public decimal Amount { get; set; }

    public string Category { get; set; } = string.Empty;

    public string? Description { get; set; }

    public DateTime Date { get; set; }
}   