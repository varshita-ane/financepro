using Microsoft.AspNetCore.Mvc;
using financepro.Api.Services;
using financepro.Api.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
namespace financepro.Api.Controllers;
using financepro.Api.Models;

[ApiController]
[Route("api/[controller]")]
public class AIController : ControllerBase
{
    private readonly FinanceAIService _aiService;
    private readonly FinanceDbContext _context;

    public AIController(
        FinanceAIService aiService,
        FinanceDbContext context)
    {
        _aiService = aiService;
        _context = context;
    }

    // =========================
    // ASK AI
    // =========================
    [Authorize]
[HttpPost("ask")]
public async Task<IActionResult> Ask([FromBody] AIRequest request)
{
    try
    {
        if (request == null)
        {
            return BadRequest(new
            {
                error = "Request is required."
            });
        }

        if (string.IsNullOrWhiteSpace(request.Question))
        {
            return BadRequest(new
            {
                error = "Question is required."
            });
        }

        // Get the logged-in user's ID from JWT
        var userIdClaim = User.FindFirst(
            System.Security.Claims.ClaimTypes.NameIdentifier
        );

        if (userIdClaim == null)
        {
            return Unauthorized(new
            {
                error = "User identity not found."
            });
        }

        if (!int.TryParse(userIdClaim.Value, out int userId))
        {
            return Unauthorized(new
            {
                error = "Invalid user identity."
            });
        }

        var answer = await _aiService.AskAsync(
            userId,
            request.Question,
            request.ChatHistory
        );

        return Ok(new
        {
            answer = answer
        });
    }
    catch (Exception ex)
    {
        return StatusCode(500, new
        {
            error = ex.ToString()
        });
    }
}
    // =========================
    // GET CHAT HISTORY
    // =========================
[Authorize]
[HttpGet("history")]
public async Task<IActionResult> GetChatHistory()
{
    var userIdClaim = User.FindFirst(
        System.Security.Claims.ClaimTypes.NameIdentifier
    );

    if (userIdClaim == null)
    {
        return Unauthorized(new
        {
            error = "User identity not found."
        });
    }

    if (!int.TryParse(userIdClaim.Value, out int userId))
    {
        return Unauthorized(new
        {
            error = "Invalid user identity."
        });
    }

    var messages = await _context.AIChatMessages
        .Where(x => x.UserId == userId)
        .OrderBy(x => x.CreatedAt)
        .Select(x => new
        {
            role = x.Role,
            content = x.Content,
            createdAt = x.CreatedAt
        })
        .ToListAsync();

    return Ok(messages);
}


// =========================
// AI REQUEST
// =========================


public class AIRequest
{
    public int UserId { get; set; }
    public string Question { get; set; } = string.Empty;
    public List<AIChatMessage> ChatHistory { get; set; } = new();
}
}


