using financepro.Api.Data;
using financepro.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace financepro.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ExpenseController : ControllerBase
{
    private readonly FinanceDbContext _context;

    public ExpenseController(FinanceDbContext context)
    {
        _context = context;
    }


    // =========================
    // GET ALL EXPENSES
    // =========================

    [HttpGet]
    public async Task<IActionResult> GetExpenses()
    {
        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        var expenses = await _context.Expenses
            .Where(e => e.UserId == userId.Value)
            .OrderByDescending(e => e.Date)
            .ToListAsync();

        return Ok(expenses);
    }


    // =========================
    // GET TOTAL EXPENSES
    // =========================

    [HttpGet("total")]
    public async Task<IActionResult> GetTotalExpenses()
    {
        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        var total = await _context.Expenses
            .Where(e => e.UserId == userId.Value)
            .SumAsync(e => e.Amount);

        return Ok(new
        {
            totalExpenses = total
        });
    }


    // =========================
    // GET EXPENSES BY CATEGORY
    // =========================

    [HttpGet("category/{category}")]
    public async Task<IActionResult> GetByCategory(string category)
    {
        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        var expenses = await _context.Expenses
            .Where(e =>
                e.UserId == userId.Value &&
                e.Category == category)
            .OrderByDescending(e => e.Date)
            .ToListAsync();

        return Ok(expenses);
    }


    // =========================
    // ADD EXPENSE
    // =========================

    [HttpPost]
    public async Task<IActionResult> AddExpense(
        [FromBody] ExpenseRequest request)
    {
        if (request == null)
        {
            return BadRequest(new
            {
                message = "Request is required."
            });
        }

        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        if (string.IsNullOrWhiteSpace(request.Description))
        {
            return BadRequest(new
            {
                message = "Description is required."
            });
        }

        if (request.Amount <= 0)
        {
            return BadRequest(new
            {
                message = "Amount must be greater than zero."
            });
        }

        if (string.IsNullOrWhiteSpace(request.Category))
        {
            return BadRequest(new
            {
                message = "Category is required."
            });
        }

        if (request.Type != "Need" && request.Type != "Want")
        {
            return BadRequest(new
            {
                message = "Expense type must be Need or Want."
            });
        }

        var expense = new Expense
        {
            UserId = userId.Value,
            Description = request.Description.Trim(),
            Amount = request.Amount,
            Category = request.Category.Trim(),
            Type = request.Type,
            Date = request.Date
        };

        _context.Expenses.Add(expense);

        await _context.SaveChangesAsync();

        return Ok(new
        {
            message = "Expense added successfully.",
            expense = expense
        });
    }


    // =========================
    // DELETE EXPENSE
    // =========================

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteExpense(int id)
    {
        var userId = GetUserId();

        if (userId == null)
            return Unauthorized();

        var expense = await _context.Expenses
            .FirstOrDefaultAsync(e =>
                e.Id == id &&
                e.UserId == userId.Value);

        if (expense == null)
        {
            return NotFound(new
            {
                message = "Expense not found."
            });
        }

        _context.Expenses.Remove(expense);

        await _context.SaveChangesAsync();

        return Ok(new
        {
            message = "Expense deleted successfully."
        });
    }


    // =========================
    // GET USER ID FROM JWT
    // =========================

    private int? GetUserId()
    {
        var userIdClaim = User.FindFirst(
            System.Security.Claims.ClaimTypes.NameIdentifier
        );

        if (userIdClaim == null)
            return null;

        if (!int.TryParse(userIdClaim.Value, out int userId))
            return null;

        return userId;
    }
}


// =========================
// EXPENSE REQUEST
// =========================

public class ExpenseRequest
{
    public string Description { get; set; } = string.Empty;

    public decimal Amount { get; set; }

    public string Category { get; set; } = string.Empty;

    public string Type { get; set; } = "Need";

    public DateTime Date { get; set; }
}