using financepro.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace financepro.Api.Data;

public class FinanceDbContext : DbContext
{
    public FinanceDbContext(DbContextOptions<FinanceDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users { get; set; }

    public DbSet<Income> Incomes { get; set; }

public DbSet<Expense> Expenses { get; set; }

public DbSet<AIChatMessage> AIChatMessages { get; set; }
}
